package com.example.geektrust.validators;

public class AddRiderCommandValidator implements ICommandValidator {}
