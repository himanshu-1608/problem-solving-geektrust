package com.example.geektrust.parsers.argument;

public abstract class CommandArgument {}
