package com.example.geektrust.constants;

public enum RideStatus {
    STARTED, COMPLETED
}
