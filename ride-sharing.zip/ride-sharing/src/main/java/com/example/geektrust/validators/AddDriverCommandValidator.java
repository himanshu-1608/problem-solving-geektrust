package com.example.geektrust.validators;

public class AddDriverCommandValidator implements ICommandValidator {}
