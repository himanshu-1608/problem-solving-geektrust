package com.example.geektrust.constants;

public enum RidingStatus {
    IDLE, RIDING
}
