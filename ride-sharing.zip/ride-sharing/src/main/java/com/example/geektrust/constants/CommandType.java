package com.example.geektrust.constants;

public enum CommandType {
    ADD_DRIVER, ADD_RIDER, MATCH, START_RIDE, STOP_RIDE, BILL
}
