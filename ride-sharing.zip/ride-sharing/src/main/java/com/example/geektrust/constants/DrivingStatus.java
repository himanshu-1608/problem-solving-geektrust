package com.example.geektrust.constants;

public enum DrivingStatus {
    AVAILABLE, BOOKED
}
