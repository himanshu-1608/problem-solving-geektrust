#!/bin/bash

mvn clean test
mvn jacoco:report