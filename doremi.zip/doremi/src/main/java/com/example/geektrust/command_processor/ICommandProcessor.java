package com.example.geektrust.command_processor;

import java.util.List;

public interface ICommandProcessor {

    void process(List<String> commandArguments);

}
