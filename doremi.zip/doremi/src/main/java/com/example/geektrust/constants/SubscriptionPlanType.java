package com.example.geektrust.constants;

public enum SubscriptionPlanType {
    FREE, PERSONAL, PREMIUM
}
