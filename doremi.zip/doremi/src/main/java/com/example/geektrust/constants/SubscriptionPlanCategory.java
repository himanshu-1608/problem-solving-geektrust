package com.example.geektrust.constants;

public enum SubscriptionPlanCategory {
    MUSIC, VIDEO, PODCAST
}
