package com.example.geektrust.constants;

public enum TopupPlanType {
    FOUR_DEVICE, TEN_DEVICE
}
