package com.example.geektrust.constants;

public enum CommandType {
    START_SUBSCRIPTION,
    ADD_SUBSCRIPTION,
    ADD_TOPUP,
    PRINT_RENEWAL_DETAILS
}
