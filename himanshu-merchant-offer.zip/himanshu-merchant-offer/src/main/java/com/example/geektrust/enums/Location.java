package com.example.geektrust.enums;

public enum Location {
    KARNATAKA, TAMIL_NADU, HARYANA
}
