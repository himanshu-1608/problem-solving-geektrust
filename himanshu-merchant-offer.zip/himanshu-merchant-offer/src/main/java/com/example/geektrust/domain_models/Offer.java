package com.example.geektrust.domain_models;

public class Offer {

    private final String id;

    private final String description;

    public Offer(String id, String description) {
        this.id = id;
        this.description = description;
    }

}
